import Vue from 'vue';
import Vuex from 'vuex';
import dedication from './modules/dedication';
import customer from "./modules/customer";
import login from './modules/login';
import ticket from './modules/ticket';
import stands from './modules/stands';

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    dedication,
    customer,
    login,
    ticket,
    stands,
  },
});