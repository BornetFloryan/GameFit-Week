<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
</script>
<style>
*, ::before, ::after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Roboto', sans-serif;
  font-size: 16px;
  line-height: 1.5;
  color: #333;
  background-color: #f4f4f4;
}

a {
  color: black;
  text-decoration: none;
}

</style>