<template>
  <div>
    <BracketsDisplay />
  </div>
</template>


<script>

import {defineComponent} from "vue";
import BracketsDisplay from "@/components/BracketsDisplay.vue";


export default defineComponent({
  components: { BracketsDisplay }
})
</script>

<style scoped>

</style>