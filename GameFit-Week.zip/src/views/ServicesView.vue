<template>
  <div class="services-view">
    <NavView />
    <router-view />
  </div>
</template>

<script>
import NavView from '@/components/NavBar.vue';
import { mapState } from 'vuex';

export default {
  name: 'ServicesView',
  components: { NavView },
  computed: {
    ...mapState('service', ['selectedService'])
  },
};
</script>

<style scoped>
</style>
