import AccountView from "@/views/AccountView.vue";
import ProfilView from "@/components/ProfilView.vue";
import ReservationView from "@/components/ReservationView.vue";
import TicketView from "@/components/TicketView.vue";
import LoginView from "@/views/LoginView.vue";


export default [
    {
        path: '/account',
        name: 'account',
        component: AccountView,
        children: [
            {
              path: 'login',
              name: 'login',
              component: LoginView,

            },
            {
              path: 'register',
              name: 'register',
              component: LoginView,
            },
            {
                path: 'profil',
                name: 'profil',
                component: ProfilView,
            },
            {
                path: "reservation",
                name: "reservation",
                component: ReservationView,
            },
            {
                path: "ticket",
                name: "ticket",
                component: TicketView,
            },
        ]
    },
];