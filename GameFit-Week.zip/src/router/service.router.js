import ServicesView from "../views/ServicesView.vue";
import DedicationView from "@/components/Dedication.vue";
import StreamView from "@/components/StreamView.vue";
import BracketsView from "@/views/BracketsView.vue";

export default [
    {
        path: '/services',
        name: 'services',
        component: ServicesView,
        children: [
            {
                path: 'dedication',
                name: 'dedication',
                component: DedicationView,
                props: route => ({ selectedAnimator: route.params.selectedAnimator })
            },
            {
                path: 'stream',
                name: 'stream',
                component: StreamView,
            },
            {
                path: 'brackets',
                name: 'brackets',
                component: BracketsView,
            },
        ]
    },
];