import Vue from 'vue'
import VueRouter from 'vue-router'
import AccueilView from '../views/AccueilView.vue'
import TicketingView from "@/views/TicketingView.vue";
import AdminDashBoardView from '../views/admin/AdminDashBoardView.vue';
import AdminDedication from '../views/admin/AdminDedication.vue';
import PrestataireInfoView from '@/views/PrestataireInfoView.vue';

import AccountRoutes from './account.router';
import ServiceRoutes from './service.router';


Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'home',
    component: AccueilView
  },
  {
    path: '/ticketing',
    name: 'ticketing',
    component: TicketingView
  },
  {
    path: '/prestataire/:id',
    name: 'PrestataireInfo',
    component: PrestataireInfoView
  },
  {
    path: '/admindashboard',
    name: 'admindashboard',
    component: AdminDashBoardView,
    children: [
      {
        path: 'admindedication',
        name: 'admindedication',
        component: AdminDedication,
      },
    ],
  },
    ...AccountRoutes,
    ...ServiceRoutes
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
